/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/options/index.tsx"
/*!*******************************!*\
  !*** ./src/options/index.tsx ***!
  \*******************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/.pnpm/react@18.3.1/node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_dom_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-dom/client */ "./node_modules/.pnpm/react-dom@18.3.1_react@18.3.1/node_modules/react-dom/client.js");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! antd */ "./node_modules/.pnpm/antd@5.29.3_react-dom@18.3.1_react@18.3.1__react@18.3.1/node_modules/antd/es/card/index.js");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! antd */ "./node_modules/.pnpm/antd@5.29.3_react-dom@18.3.1_react@18.3.1__react@18.3.1/node_modules/antd/es/collapse/index.js");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! antd */ "./node_modules/.pnpm/antd@5.29.3_react-dom@18.3.1_react@18.3.1__react@18.3.1/node_modules/antd/es/form/index.js");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! antd */ "./node_modules/.pnpm/antd@5.29.3_react-dom@18.3.1_react@18.3.1__react@18.3.1/node_modules/antd/es/input-number/index.js");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! antd */ "./node_modules/.pnpm/antd@5.29.3_react-dom@18.3.1_react@18.3.1__react@18.3.1/node_modules/antd/es/message/index.js");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! antd */ "./node_modules/.pnpm/antd@5.29.3_react-dom@18.3.1_react@18.3.1__react@18.3.1/node_modules/antd/es/select/index.js");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! antd */ "./node_modules/.pnpm/antd@5.29.3_react-dom@18.3.1_react@18.3.1__react@18.3.1/node_modules/antd/es/switch/index.js");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! antd */ "./node_modules/.pnpm/antd@5.29.3_react-dom@18.3.1_react@18.3.1__react@18.3.1/node_modules/antd/es/tooltip/index.js");
/* harmony import */ var _utils_default_model__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../utils/default-model */ "./src/utils/default-model.ts");




const { Option } = antd__WEBPACK_IMPORTED_MODULE_7__["default"];
const { Panel } = antd__WEBPACK_IMPORTED_MODULE_3__["default"];
// Simple question circle icon component (avoids @ant-design/icons dependency)
const QuestionCircleIcon = () => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { style: {
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        width: '14px',
        height: '14px',
        borderRadius: '50%',
        border: '1px solid #1890ff',
        fontSize: '10px',
        color: '#1890ff',
        marginLeft: '4px',
        cursor: 'help'
    } }, "?"));
const DEFAULT_MULTI_AGENT_CONFIG = {
    maxSubTaskSteps: 10,
    maxSubTasks: 5,
    maxIterations: 10,
    maxHistorySummaries: 5,
};
const OptionsPage = () => {
    const [form] = antd__WEBPACK_IMPORTED_MODULE_4__["default"].useForm();
    const [config, setConfig] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({
        llm: "anthropic",
        apiKey: "",
        // Will be replaced from chrome.storage on mount; safe sentinel for first paint.
        modelName: _utils_default_model__WEBPACK_IMPORTED_MODULE_10__.BUILTIN_DEFAULT_LLM_MODEL,
        apiType: "chat-completion",
        options: {
            // Will be replaced from chrome.storage on mount; safe fallback for first paint.
            baseURL: "https://api.anthropic.com/v1",
        },
    });
    // Agent mode state (separate from LLM config)
    const [agentMode, setAgentMode] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("single");
    const [multiAgentConfig, setMultiAgentConfig] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(DEFAULT_MULTI_AGENT_CONFIG);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        // Load LLM config
        chrome.storage.sync.get(["llmConfig", "defaultLlmModel"], (result) => {
            if (result.llmConfig) {
                if (result.llmConfig.llm === "") {
                    result.llmConfig.llm = "anthropic";
                }
                // Backfill modelName from defaultLlmModel storage key if the
                // persisted llmConfig is missing one.
                if (!result.llmConfig.modelName) {
                    result.llmConfig.modelName = (0,_utils_default_model__WEBPACK_IMPORTED_MODULE_10__.defaultLlmModelFromStored)(result.defaultLlmModel);
                }
                setConfig(result.llmConfig);
                form.setFieldsValue(result.llmConfig);
            }
            else if (result.defaultLlmModel) {
                // No persisted llmConfig yet; reflect the resolver-pinned default
                // model in the form's initial state.
                setConfig((prev) => ({ ...prev, modelName: (0,_utils_default_model__WEBPACK_IMPORTED_MODULE_10__.defaultLlmModelFromStored)(result.defaultLlmModel) }));
                form.setFieldsValue({ modelName: (0,_utils_default_model__WEBPACK_IMPORTED_MODULE_10__.defaultLlmModelFromStored)(result.defaultLlmModel) });
            }
        });
        // Load agent mode config
        chrome.storage.sync.get(["agentModeConfig"], (result) => {
            if (result.agentModeConfig) {
                setAgentMode(result.agentModeConfig.mode || "single");
                setMultiAgentConfig({
                    ...DEFAULT_MULTI_AGENT_CONFIG,
                    ...result.agentModeConfig.multiAgentConfig,
                });
            }
        });
    }, []);
    const handleSave = () => {
        form
            .validateFields()
            .then((values) => {
            setConfig(values);
            chrome.storage.sync.set({
                llmConfig: values,
            }, () => {
                antd__WEBPACK_IMPORTED_MODULE_6__["default"].success("LLM Config Saved!");
            });
        })
            .catch(() => {
            antd__WEBPACK_IMPORTED_MODULE_6__["default"].error("Please check the form field");
        });
    };
    // Save agent mode configuration
    const handleAgentModeChange = (checked) => {
        const newMode = checked ? "multi" : "single";
        setAgentMode(newMode);
        chrome.storage.sync.set({
            agentModeConfig: {
                mode: newMode,
                multiAgentConfig: multiAgentConfig,
            },
        }, () => {
            antd__WEBPACK_IMPORTED_MODULE_6__["default"].success(`Agent mode set to: ${newMode === "multi" ? "Multi-Agent" : "Single-Agent"}`);
        });
    };
    // Save multi-agent configuration
    const handleMultiAgentConfigChange = (key, value) => {
        const newConfig = { ...multiAgentConfig, [key]: value };
        setMultiAgentConfig(newConfig);
        chrome.storage.sync.set({
            agentModeConfig: {
                mode: agentMode,
                multiAgentConfig: newConfig,
            },
        });
    };
    const modelLLMs = [
        { value: "anthropic", label: "Claude" },
        { value: "openai", label: "OpenAI" },
    ];
    const modelOptions = {
        anthropic: [
            { value: "claude-opus-4-7", label: "Claude Opus 4.7" },
            { value: "claude-sonnet-4-6", label: "Claude Sonnet 4.6" },
            { value: "claude-haiku-4-5", label: "Claude Haiku 4.5" },
        ],
        openai: [
            { value: "gpt-4-turbo", label: "GPT-4 Turbo" },
            { value: "gpt-4", label: "GPT-4" },
            { value: "gpt-3.5-turbo", label: "GPT-3.5 Turbo" },
        ],
    };
    const handleLLMChange = (value) => {
        const baseURLMap = {
            openai: "https://api.openai.com/v1",
            anthropic: "https://api.anthropic.com/v1",
        };
        const newConfig = {
            llm: value,
            apiKey: "",
            modelName: modelOptions[value][0].value,
            apiType: "chat-completion",
            options: {
                baseURL: baseURLMap[value]
            },
        };
        setConfig(newConfig);
        form.setFieldsValue(newConfig);
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "p-6 max-w-xl mx-auto" },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_2__["default"], { title: "Browser Extension", className: "shadow-md" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { padding: '12px', background: '#f6ffed', borderRadius: '6px', border: '1px solid #b7eb8f' } },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { style: { color: '#52c41a' } }, "\u2705 Extension is installed. Use the sidebar panel to configure settings and run tasks."))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_2__["default"], { title: "Agent Mode", className: "shadow-md", style: { marginTop: '16px' } },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_4__["default"], { layout: "vertical" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_4__["default"].Item, { label: react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null,
                        "Enable Multi-Agent Mode",
                        ' ',
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_9__["default"], { title: "Multi-agent mode decomposes complex tasks into sub-tasks, each executed by a fresh agent with clean context. This helps prevent context overflow during long-running tasks." },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(QuestionCircleIcon, null))) },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_8__["default"], { checked: agentMode === "multi", onChange: handleAgentModeChange, checkedChildren: "Multi-Agent", unCheckedChildren: "Single-Agent" })),
                agentMode === "multi" && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_3__["default"], { ghost: true },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(Panel, { header: "Advanced Multi-Agent Settings", key: "1" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_4__["default"].Item, { label: react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null,
                                "Max Steps per Sub-task",
                                ' ',
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_9__["default"], { title: "Maximum number of browser actions each child agent can perform per sub-task" },
                                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(QuestionCircleIcon, null))) },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_5__["default"], { min: 1, max: 50, value: multiAgentConfig.maxSubTaskSteps, onChange: (value) => handleMultiAgentConfigChange('maxSubTaskSteps', value || 10) })),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_4__["default"].Item, { label: react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null,
                                "Max Sub-tasks per Iteration",
                                ' ',
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_9__["default"], { title: "Maximum number of sub-tasks the planner can create in each planning iteration" },
                                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(QuestionCircleIcon, null))) },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_5__["default"], { min: 1, max: 10, value: multiAgentConfig.maxSubTasks, onChange: (value) => handleMultiAgentConfigChange('maxSubTasks', value || 5) })),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_4__["default"].Item, { label: react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null,
                                "Max Planning Iterations",
                                ' ',
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_9__["default"], { title: "Maximum number of plan-execute cycles before giving up" },
                                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(QuestionCircleIcon, null))) },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_5__["default"], { min: 1, max: 30, value: multiAgentConfig.maxIterations, onChange: (value) => handleMultiAgentConfigChange('maxIterations', value || 10) })),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_4__["default"].Item, { label: react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null,
                                "History Summaries to Keep",
                                ' ',
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_9__["default"], { title: "Number of recent sub-task summaries to pass to the planner (higher = more context, lower = less memory)" },
                                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(QuestionCircleIcon, null))) },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(antd__WEBPACK_IMPORTED_MODULE_5__["default"], { min: 1, max: 20, value: multiAgentConfig.maxHistorySummaries, onChange: (value) => handleMultiAgentConfigChange('maxHistorySummaries', value || 5) }))))),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { padding: '12px', background: agentMode === 'multi' ? '#f6ffed' : '#f5f5f5', borderRadius: '6px', border: `1px solid ${agentMode === 'multi' ? '#b7eb8f' : '#d9d9d9'}`, marginTop: '12px' } }, agentMode === 'multi' ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { style: { color: '#52c41a' } },
                    "\uD83D\uDD00 ",
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("strong", null, "Multi-Agent Mode:"),
                    " Tasks are decomposed into sub-tasks. Each sub-task runs with fresh context, helping prevent context overflow during complex tasks.")) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { style: { color: '#595959' } },
                    "\uD83D\uDD39 ",
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("strong", null, "Single-Agent Mode (Default):"),
                    " Traditional single-agent execution. Best for simple tasks or when you need full context continuity.")))))));
};
const root = (0,react_dom_client__WEBPACK_IMPORTED_MODULE_1__.createRoot)(document.getElementById("root"));
root.render(react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().StrictMode), null,
    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(OptionsPage, null)));


/***/ },

/***/ "./src/utils/default-model.ts"
/*!************************************!*\
  !*** ./src/utils/default-model.ts ***!
  \************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   BUILTIN_DEFAULT_LLM_MODEL: () => (/* binding */ BUILTIN_DEFAULT_LLM_MODEL),
/* harmony export */   defaultLlmModelFromStored: () => (/* binding */ defaultLlmModelFromStored),
/* harmony export */   getDefaultLlmModel: () => (/* binding */ getDefaultLlmModel)
/* harmony export */ });
/**
 * Resolve the default LLM model name used by `private-anthropic-*`
 * providers (and any provider whose dropdown the user hasn't touched).
 *
 * Mirrors `utils/sdf-endpoint.ts`: a chrome.storage.sync key
 * (`defaultLlmModel`) lets the resolver — or a power user — pin the
 * default model without code changes. When unset, helpers fall back to
 * `BUILTIN_DEFAULT_LLM_MODEL` so the extension still works for first-
 * time users.
 */
/** Last-resort default when neither storage nor caller specifies a model. */
const BUILTIN_DEFAULT_LLM_MODEL = 'claude-opus-4-7';
async function getDefaultLlmModel() {
    try {
        const { defaultLlmModel } = await chrome.storage.sync.get(['defaultLlmModel']);
        if (typeof defaultLlmModel === 'string' && defaultLlmModel.trim()) {
            return defaultLlmModel.trim();
        }
    }
    catch (_a) {
        // chrome.storage may be unavailable in some test contexts.
    }
    return BUILTIN_DEFAULT_LLM_MODEL;
}
function defaultLlmModelFromStored(value) {
    if (typeof value === 'string' && value.trim()) {
        return value.trim();
    }
    return BUILTIN_DEFAULT_LLM_MODEL;
}


/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			id: moduleId,
/******/ 			loaded: false,
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		if (!(moduleId in __webpack_modules__)) {
/******/ 			delete __webpack_module_cache__[moduleId];
/******/ 			var e = new Error("Cannot find module '" + moduleId + "'");
/******/ 			e.code = 'MODULE_NOT_FOUND';
/******/ 			throw e;
/******/ 		}
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = __webpack_modules__;
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/chunk loaded */
/******/ 	(() => {
/******/ 		var deferred = [];
/******/ 		__webpack_require__.O = (result, chunkIds, fn, priority) => {
/******/ 			if(chunkIds) {
/******/ 				priority = priority || 0;
/******/ 				for(var i = deferred.length; i > 0 && deferred[i - 1][2] > priority; i--) deferred[i] = deferred[i - 1];
/******/ 				deferred[i] = [chunkIds, fn, priority];
/******/ 				return;
/******/ 			}
/******/ 			var notFulfilled = Infinity;
/******/ 			for (var i = 0; i < deferred.length; i++) {
/******/ 				var [chunkIds, fn, priority] = deferred[i];
/******/ 				var fulfilled = true;
/******/ 				for (var j = 0; j < chunkIds.length; j++) {
/******/ 					if ((priority & 1 === 0 || notFulfilled >= priority) && Object.keys(__webpack_require__.O).every((key) => (__webpack_require__.O[key](chunkIds[j])))) {
/******/ 						chunkIds.splice(j--, 1);
/******/ 					} else {
/******/ 						fulfilled = false;
/******/ 						if(priority < notFulfilled) notFulfilled = priority;
/******/ 					}
/******/ 				}
/******/ 				if(fulfilled) {
/******/ 					deferred.splice(i--, 1)
/******/ 					var r = fn();
/******/ 					if (r !== undefined) result = r;
/******/ 				}
/******/ 			}
/******/ 			return result;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/create fake namespace object */
/******/ 	(() => {
/******/ 		var getProto = Object.getPrototypeOf ? (obj) => (Object.getPrototypeOf(obj)) : (obj) => (obj.__proto__);
/******/ 		var leafPrototypes;
/******/ 		// create a fake namespace object
/******/ 		// mode & 1: value is a module id, require it
/******/ 		// mode & 2: merge all properties of value into the ns
/******/ 		// mode & 4: return value when already ns object
/******/ 		// mode & 16: return value when it's Promise-like
/******/ 		// mode & 8|1: behave like require
/******/ 		__webpack_require__.t = function(value, mode) {
/******/ 			if(mode & 1) value = this(value);
/******/ 			if(mode & 8) return value;
/******/ 			if(typeof value === 'object' && value) {
/******/ 				if((mode & 4) && value.__esModule) return value;
/******/ 				if((mode & 16) && typeof value.then === 'function') return value;
/******/ 			}
/******/ 			var ns = Object.create(null);
/******/ 			__webpack_require__.r(ns);
/******/ 			var def = {};
/******/ 			leafPrototypes = leafPrototypes || [null, getProto({}), getProto([]), getProto(getProto)];
/******/ 			for(var current = mode & 2 && value; (typeof current == 'object' || typeof current == 'function') && !~leafPrototypes.indexOf(current); current = getProto(current)) {
/******/ 				Object.getOwnPropertyNames(current).forEach((key) => (def[key] = () => (value[key])));
/******/ 			}
/******/ 			def['default'] = () => (value);
/******/ 			__webpack_require__.d(ns, def);
/******/ 			return ns;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/harmony module decorator */
/******/ 	(() => {
/******/ 		__webpack_require__.hmd = (module) => {
/******/ 			module = Object.create(module);
/******/ 			if (!module.children) module.children = [];
/******/ 			Object.defineProperty(module, 'exports', {
/******/ 				enumerable: true,
/******/ 				set: () => {
/******/ 					throw new Error('ES Modules may not assign module.exports or exports.*, Use ESM export syntax, instead: ' + module.id);
/******/ 				}
/******/ 			});
/******/ 			return module;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/node module decorator */
/******/ 	(() => {
/******/ 		__webpack_require__.nmd = (module) => {
/******/ 			module.paths = [];
/******/ 			if (!module.children) module.children = [];
/******/ 			return module;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/jsonp chunk loading */
/******/ 	(() => {
/******/ 		// no baseURI
/******/ 		
/******/ 		// object to store loaded and loading chunks
/******/ 		// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 		// [resolve, reject, Promise] = chunk loading, 0 = chunk loaded
/******/ 		var installedChunks = {
/******/ 			"options": 0
/******/ 		};
/******/ 		
/******/ 		// no chunk on demand loading
/******/ 		
/******/ 		// no prefetching
/******/ 		
/******/ 		// no preloaded
/******/ 		
/******/ 		// no HMR
/******/ 		
/******/ 		// no HMR manifest
/******/ 		
/******/ 		__webpack_require__.O.j = (chunkId) => (installedChunks[chunkId] === 0);
/******/ 		
/******/ 		// install a JSONP callback for chunk loading
/******/ 		var webpackJsonpCallback = (parentChunkLoadingFunction, data) => {
/******/ 			var [chunkIds, moreModules, runtime] = data;
/******/ 			// add "moreModules" to the modules object,
/******/ 			// then flag all "chunkIds" as loaded and fire callback
/******/ 			var moduleId, chunkId, i = 0;
/******/ 			if(chunkIds.some((id) => (installedChunks[id] !== 0))) {
/******/ 				for(moduleId in moreModules) {
/******/ 					if(__webpack_require__.o(moreModules, moduleId)) {
/******/ 						__webpack_require__.m[moduleId] = moreModules[moduleId];
/******/ 					}
/******/ 				}
/******/ 				if(runtime) var result = runtime(__webpack_require__);
/******/ 			}
/******/ 			if(parentChunkLoadingFunction) parentChunkLoadingFunction(data);
/******/ 			for(;i < chunkIds.length; i++) {
/******/ 				chunkId = chunkIds[i];
/******/ 				if(__webpack_require__.o(installedChunks, chunkId) && installedChunks[chunkId]) {
/******/ 					installedChunks[chunkId][0]();
/******/ 				}
/******/ 				installedChunks[chunkId] = 0;
/******/ 			}
/******/ 			return __webpack_require__.O(result);
/******/ 		}
/******/ 		
/******/ 		var chunkLoadingGlobal = self["webpackChunk_eko_ai_eko_extension_standalone"] = self["webpackChunk_eko_ai_eko_extension_standalone"] || [];
/******/ 		chunkLoadingGlobal.forEach(webpackJsonpCallback.bind(null, 0));
/******/ 		chunkLoadingGlobal.push = webpackJsonpCallback.bind(null, chunkLoadingGlobal.push.bind(chunkLoadingGlobal));
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module depends on other loaded chunks and execution need to be delayed
/******/ 	var __webpack_exports__ = __webpack_require__.O(undefined, ["vendor"], () => (__webpack_require__("./src/options/index.tsx")))
/******/ 	__webpack_exports__ = __webpack_require__.O(__webpack_exports__);
/******/ 	
/******/ })()
;
//# sourceMappingURL=options.js.map